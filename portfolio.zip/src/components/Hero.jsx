import {
  motion,
  useScroll,
  useTransform,
  useReducedMotion,
} from "framer-motion";
import { useEffect, useState } from "react";

const text = "Portfolio unlocked! Prepare for a wild ride through my code";

export default function Hero() {
  const prefersReducedMotion = useReducedMotion();
  const { scrollY } = useScroll();

  /* ===== Scroll-based cinematic effects ===== */
  const fade = useTransform(scrollY, [0, 300], [1, 0.85]);
  const scale = useTransform(scrollY, [0, 300], [1, 0.96]);

  /* ===== Blob parallax ===== */
  const y1 = useTransform(scrollY, [0, 600], [0, -80]);
  const y2 = useTransform(scrollY, [0, 600], [0, 120]);
  const y3 = useTransform(scrollY, [0, 600], [0, -160]);

  /* ===== Mouse parallax (name) ===== */
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  useEffect(() => {
    if (prefersReducedMotion) return;
    const move = (e) =>
      setMouse({
        x: (e.clientX / window.innerWidth - 0.5) * 18,
        y: (e.clientY / window.innerHeight - 0.5) * 18,
      });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, [prefersReducedMotion]);

  /* ===== Typewriter ===== */
  const [typed, setTyped] = useState("");
  useEffect(() => {
    let i = 0;
    const t = setInterval(() => {
      setTyped(text.slice(0, i));
      i++;
      if (i > text.length) clearInterval(t);
    }, 32);
    return () => clearInterval(t);
  }, []);

  return (
    <motion.section style={{ ...section, opacity: fade, scale }}>
      {/* Floating blobs */}
      <motion.div className="hero-blob blob-1" style={{ y: y1 }} />
      <motion.div className="hero-blob blob-2" style={{ y: y2 }} />
      <motion.div className="hero-blob blob-3" style={{ y: y3 }} />

      <div style={content}>
        {/* Pill */}
        <motion.div
          style={pill}
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Full Stack Developer
        </motion.div>

        {/* Name */}
        <motion.h1
          className="gradient-text"
          style={{
            ...name,
            transform: prefersReducedMotion
              ? "none"
              : `translate(${mouse.x}px, ${mouse.y}px)`,
          }}
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9 }}
        >
          Yarlagadda
          <br />
          Medhamsh
        </motion.h1>

        {/* Terminal line (alive pulse) */}
        <motion.div
          style={terminalLine}
          animate={{ opacity: [0.85, 1, 0.85] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          <span>{typed}</span>
          <span className="typing-cursor">_</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ================= STYLES ================= */

const section = {
  minHeight: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  position: "relative",
  overflow: "hidden",
};

const content = {
  textAlign: "center",
  zIndex: 2,
  maxWidth: "900px",
  padding: "0 20px",
};

const pill = {
  display: "inline-block",
  padding: "6px 16px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.25)",
  background: "rgba(255,255,255,0.04)",
  fontSize: "0.8rem",
  marginBottom: "26px",
  backdropFilter: "blur(6px)",
};

const name = {
  fontSize: "clamp(3.2rem, 6vw, 5.2rem)",
  fontWeight: 700,
  lineHeight: 1.05,
  letterSpacing: "-0.02em",
};

const terminalLine = {
  marginTop: "26px",
  padding: "14px 22px",
  borderRadius: "10px",
  border: "1px solid rgba(255,255,255,0.18)",
  background: "rgba(0,0,0,0.45)",
  fontFamily: "monospace",
  fontSize: "0.95rem",
  display: "inline-flex",
  gap: "4px",
};

