import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function Preloader({ onFinish }) {
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(onFinish, 600);
          return 100;
        }
        return p + 1;
      });
    }, 30);

    const stepTimer = setInterval(() => {
      setStep((s) => Math.min(s + 1, 2));
    }, 800);

    return () => {
      clearInterval(interval);
      clearInterval(stepTimer);
    };
  }, [onFinish]);

  return (
    <div style={wrapper}>
      {/* LOGO */}
      <motion.h1
        style={logo}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {"<>"}
        <span style={{ color: "var(--accent)" }}> MEDHAMSH</span>
        <span style={{ color: "#8b5cf6" }}>.DEV</span>
        {" _"}
      </motion.h1>

      {/* TERMINAL */}
      <motion.div
        style={terminal}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div style={terminalHeader}>
          <span style={{ ...dot, background: "#ff5f56" }} />
          <span style={{ ...dot, background: "#ffbd2e" }} />
          <span style={{ ...dot, background: "#27c93f" }} />
          <span style={terminalTitle}>portfolio-init.sh</span>
        </div>

        <div style={terminalBody}>
          <Line visible={step >= 0}>
            $ Loading system modules... <span style={ok}>✓</span>
          </Line>
          <Line visible={step >= 1}>
            $ Initializing portfolio engine...
          </Line>
          <Line visible={step >= 2}>
            $ Launch sequence armed
          </Line>
        </div>
      </motion.div>

      {/* PROGRESS BAR */}
      <div style={progressWrap}>
        <div style={progressLabel}>
          Initializing
          <span>{progress}%</span>
          <span>Launch</span>
        </div>

        <div style={progressTrack}>
          <motion.div
            style={progressBar}
            animate={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <p style={footer}>Embarking on a digital journey...</p>
    </div>
  );
}

/* ================= SUB COMPONENT ================= */

function Line({ children, visible }) {
  return (
    <motion.div
      style={terminalLine}
      initial={{ opacity: 0 }}
      animate={{ opacity: visible ? 1 : 0 }}
    >
      {children}
    </motion.div>
  );
}

/* ================= STYLES ================= */

const wrapper = {
  minHeight: "100vh",
  background: "black",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  gap: "26px",
};

const logo = {
  fontSize: "2rem",
  fontWeight: 600,
  letterSpacing: "1px",
};

const terminal = {
  width: "380px",
  background: "#0b0f14",
  borderRadius: "12px",
  boxShadow: "0 0 80px rgba(77,181,255,0.25)",
  overflow: "hidden",
};

const terminalHeader = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  padding: "10px 12px",
  background: "#0f1623",
};

const dot = {
  width: "12px",
  height: "12px",
  borderRadius: "50%",
};

const terminalTitle = {
  marginLeft: "auto",
  fontSize: "0.75rem",
  opacity: 0.6,
};

const terminalBody = {
  padding: "16px",
  fontFamily: "Fira Code, monospace",
  fontSize: "0.85rem",
  color: "#00f6ff",
};

const terminalLine = {
  lineHeight: 1.6,
};

const ok = {
  color: "#27c93f",
};

const progressWrap = {
  width: "380px",
};

const progressLabel = {
  display: "flex",
  justifyContent: "space-between",
  fontSize: "0.75rem",
  opacity: 0.6,
  marginBottom: "6px",
};

const progressTrack = {
  height: "4px",
  background: "rgba(255,255,255,0.1)",
  borderRadius: "999px",
  overflow: "hidden",
};

const progressBar = {
  height: "100%",
  background: "linear-gradient(90deg, var(--accent), #8b5cf6)",
};

const footer = {
  fontSize: "0.75rem",
  opacity: 0.5,
};
