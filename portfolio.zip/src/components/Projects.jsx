import { motion } from "framer-motion";

export default function Projects() {
  return (
    <section id="projects">
      <div className="container">
        <h2>Projects</h2>

        <div style={grid}>
          <ChatbotCard />
          <DashboardCard />
          <PortfolioCard />
        </div>
      </div>
    </section>
  );
}

/* ================= AI CHATBOT CARD ================= */
function ChatbotCard() {
  return (
    <motion.div
      style={card}
      whileHover={{
        y: -8,
        boxShadow: "0 20px 60px rgba(77,181,255,0.35)",
      }}
      transition={{ duration: 0.25 }}
    >
      <h3>AI Chatbot</h3>
      <p style={{ opacity: 0.7, marginTop: "8px" }}>
        An AI-powered chatbot with real-time conversational UI and smooth animations.
      </p>

      {/* Chat Preview */}
      <div style={chatBox}>
        <motion.div
          style={{ ...bubble, alignSelf: "flex-end", background: "var(--accent)", color: "black" }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          Hi! What can you do?
        </motion.div>

        <motion.div
          style={{ ...bubble, alignSelf: "flex-start" }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          I can answer questions and help with tasks 🤖
        </motion.div>
      </div>

      <p style={techText}>React • JavaScript • AI APIs</p>
      <span style={link}>View Chatbot →</span>
    </motion.div>
  );
}

/* ================= DASHBOARD CARD ================= */
function DashboardCard() {
  return (
    <motion.div
      style={card}
      whileHover={{
        y: -8,
        boxShadow: "0 20px 60px rgba(77,181,255,0.35)",
      }}
      transition={{ duration: 0.25 }}
    >
      <h3>Data Analytics Dashboard</h3>
      <p style={{ opacity: 0.7, marginTop: "8px" }}>
        A responsive dashboard visualizing structured data with charts and insights.
      </p>

      <div style={chartBox}>
        {[40, 70, 55, 85, 60].map((h, i) => (
          <motion.div
            key={i}
            style={{ ...bar, height: `${h}%` }}
            whileHover={{ opacity: 1 }}
          />
        ))}
      </div>

      <p style={techText}>React • Charts • Data Handling</p>
      <span style={link}>View Dashboard →</span>
    </motion.div>
  );
}

/* ================= PORTFOLIO CARD ================= */
function PortfolioCard() {
  return (
    <motion.div
      style={card}
      whileHover={{
        y: -8,
        boxShadow: "0 20px 60px rgba(77,181,255,0.35)",
      }}
      transition={{ duration: 0.25 }}
    >
      <h3>Animated Developer Portfolio</h3>
      <p style={{ opacity: 0.7, marginTop: "8px" }}>
        A modern portfolio built with React and Framer Motion featuring a design system.
      </p>

      <p style={techText}>React • Framer Motion • CSS</p>
      <span style={link}>View Portfolio →</span>
    </motion.div>
  );
}

/* ================= STYLES ================= */
const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: "32px",
  marginTop: "40px",
};

const card = {
  background: "var(--panel)",
  padding: "28px",
  borderRadius: "var(--radius-md)",
};

const techText = {
  marginTop: "12px",
  fontSize: "0.9rem",
  color: "var(--muted)",
};

const link = {
  display: "inline-block",
  marginTop: "16px",
  color: "var(--accent)",
  fontWeight: 500,
};

/* Chat styles */
const chatBox = {
  display: "flex",
  flexDirection: "column",
  gap: "8px",
  marginTop: "16px",
};

const bubble = {
  maxWidth: "80%",
  padding: "8px 12px",
  borderRadius: "12px",
  background: "#1a1a1a",
  fontSize: "0.85rem",
};

/* Dashboard styles */
const chartBox = {
  display: "flex",
  gap: "8px",
  alignItems: "flex-end",
  height: "120px",
  marginTop: "16px",
};

const bar = {
  width: "16%",
  background: "linear-gradient(180deg, var(--accent), transparent)",
  borderRadius: "6px",
  opacity: 0.7,
};
