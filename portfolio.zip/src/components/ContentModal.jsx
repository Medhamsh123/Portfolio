import { motion } from "framer-motion";
import { useEffect } from "react";

export default function ContentModal({ open, onClose, children }) {
  // 🔒 Lock background scroll
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  if (!open) return null;

  return (
    <div style={overlay} onClick={onClose}>
      <motion.div
        style={modal}
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.25 }}
      >
        {/* ✅ SCROLLABLE CONTENT */}
        <div style={content}>
          {children}
        </div>
      </motion.div>
    </div>
  );
}

/* ================= STYLES ================= */

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.75)",
  backdropFilter: "blur(8px)",
  zIndex: 9999,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

const modal = {
  width: "92%",
  maxWidth: "900px",
  maxHeight: "90vh",          // ✅ IMPORTANT
  background: "transparent",
};

const content = {
  maxHeight: "90vh",          // ✅ IMPORTANT
  overflowY: "auto",          // ✅ SCROLL INSIDE MODAL
  paddingRight: "6px",
};
