import { motion } from "framer-motion";

const skillGroups = [
  {
    title: "Frontend",
    skills: ["HTML", "CSS", "JavaScript", "React"],
  },
  {
    title: "Backend",
    skills: ["Python", "Node.js", "Express"],
  },
  {
    title: "Tools",
    skills: ["Git", "GitHub", "VS Code"],
  },
];

export default function Skills() {
  return (
    <section id="skills">
      <div className="container">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Skills
        </motion.h2>

        <div style={grid}>
          {skillGroups.map((group, i) => (
            <motion.div
              key={group.title}
              style={card}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              whileHover={{
                boxShadow: "0 0 40px rgba(77,181,255,0.25)",
                y: -6,
              }}
            >
              <h3 style={groupTitle}>{group.title}</h3>

              <div style={skillsWrap}>
                {group.skills.map((skill) => (
                  <motion.span
                    key={skill}
                    style={skillPill}
                    whileHover={{
                      scale: 1.08,
                      background: "var(--accent)",
                      color: "#000",
                    }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ================= STYLES ================= */

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: "32px",
  marginTop: "40px",
};

const card = {
  background: "rgba(255,255,255,0.03)",
  border: "1px solid rgba(255,255,255,0.08)",
  borderRadius: "16px",
  padding: "28px",
  backdropFilter: "blur(10px)",
};

const groupTitle = {
  marginBottom: "18px",
  fontSize: "1.2rem",
  fontWeight: 500,
};

const skillsWrap = {
  display: "flex",
  flexWrap: "wrap",
  gap: "12px",
};

const skillPill = {
  padding: "8px 14px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.12)",
  fontSize: "0.85rem",
  cursor: "default",
  transition: "all 0.2s ease",
};
