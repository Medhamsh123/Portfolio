import { useState, useEffect, useRef } from "react";

export default function Terminal({ onClose }) {
  const [lines, setLines] = useState([
    "Hey there! 👋 Welcome to my interactive console.",
    "",
    "Quick Commands:",
    "whoami   → Who am I?",
    "skills   → My tech stack",
    "projects → Cool stuff I built",
    "contact  → Let's connect!",
    "ask <q>  → Ask me anything",
    "resume   → Resume info",
    "clear    → Clear terminal",
    "exit     → Close terminal",
    "",
  ]);

  const [input, setInput] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines]);

  const respond = (cmd) => {
    const lower = cmd.toLowerCase();

    if (lower === "help") {
      return [
        "Available commands:",
        "whoami, skills, projects, contact",
        "ask <question>",
        "resume, clear, exit",
      ];
    }

    if (lower === "whoami") {
      return [
        "Yarlagadda Medhamsh",
        "Full Stack Developer & AI Enthusiast",
        "I build clean UIs, scalable systems, and smart products.",
      ];
    }

    if (lower === "skills") {
      return [
        "Frontend: React, Next.js, TypeScript, Tailwind",
        "Backend: Node.js, Express, MongoDB",
        "AI/ML: LLMs, Prompt Engineering, TensorFlow",
      ];
    }

    if (lower === "projects") {
      return [
        "AI Chatbot Platform",
        "Data Analytics Dashboard",
        "Interactive Portfolio Terminal",
      ];
    }

    if (lower === "contact") {
      return [
        "Email: yarlagaddamedhamsh@gmail.com",
        "GitHub: github.com/Medhamsh123",
        "LinkedIn: linkedin.com/in/medhamsh-yarlagadda-05854b326",
      ];
    }

    if (lower.startsWith("ask ")) {
      const q = cmd.slice(4);
      return [
        `🤖 AI says:`,
        `Great question — "${q}"`,
        "I love solving real-world problems using code and AI.",
        "Let’s build something impactful together.",
      ];
    }

    if (lower === "resume") {
      return [
        "Resume status: Ready",
        "Tip: Download available in Contact section",
      ];
    }

    if (lower === "clear") {
      setLines([]);
      return [];
    }

    if (lower === "exit") {
      onClose?.();
      return [];
    }

    return [`Command not found: ${cmd}`, "Type 'help' to see commands"];
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const output = respond(input);
    setLines((prev) => [...prev, `$ ${input}`, ...output, ""]);
    setInput("");
  };

  return (
    <div className="terminal">
      <div className="terminal-header">
        <div className="dot red" onClick={onClose} />
        <div className="dot yellow" />
        <div className="dot green" />
        <span className="title">guest@medhamsh:~</span>
      </div>

      <div className="terminal-body">
        {lines.map((line, i) => (
          <div key={i} className="terminal-line">
            {line}
          </div>
        ))}

        <form onSubmit={handleSubmit} className="terminal-input">
          <span>$</span>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            autoFocus
          />
          <span className="cursor">█</span>
        </form>

        <div ref={bottomRef} />
      </div>
    </div>
  );
}
