import { motion } from "framer-motion";

export default function TerminalCard({ onOpen }) {
  return (
    <motion.div
      style={card}
      whileHover={{ y: -6, boxShadow: "0 20px 50px rgba(77,181,255,0.3)" }}
      onClick={onOpen}
    >
      <div style={icon}>&gt;_</div>
      <h3>Terminal Access</h3>
      <p style={{ opacity: 0.6 }}>
        Interactive command-line interface to explore my portfolio
      </p>
      <p style={{ marginTop: "12px", fontSize: "0.85rem", opacity: 0.4 }}>
        Click to open
      </p>
    </motion.div>
  );
}

const card = {
  background: "var(--panel)",
  padding: "28px",
  borderRadius: "var(--radius-md)",
  cursor: "pointer",
};

const icon = {
  fontSize: "1.5rem",
  marginBottom: "12px",
};
