import Terminal from "./Terminal";
import { motion } from "framer-motion";

export default function TerminalModal({ open, onClose }) {
  if (!open) return null;

  return (
    <div style={overlay} onClick={onClose}>
      <motion.div
        style={modal}
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.25 }}
      >
        {/* PASS onClose INTO TERMINAL */}
        <Terminal onClose={onClose} />
      </motion.div>
    </div>
  );
}

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.75)",
  backdropFilter: "blur(6px)",
  zIndex: 9999,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

const modal = {
  width: "90%",
  maxWidth: "800px",
};
