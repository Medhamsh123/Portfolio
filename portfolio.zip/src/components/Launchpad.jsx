import { motion } from "framer-motion";

export default function Launchpad({ onOpen }) {
  return (
    <section>
      <div className="container" style={grid}>

        <Card
          icon=">_"
          title="Terminal Access"
          desc="Interactive command-line interface to explore my portfolio"
          hint="Press Ctrl + `"
          onClick={() => onOpen("terminal")}
        />

        <Card
          icon="🧠"
          title="About Me"
          desc="Get to know my journey and skills"
          hint="whois medhamsh?"
          onClick={() => onOpen("about")}
        />

        <Card
          icon="</>"
          title="Projects"
          desc="Explore my featured works and contributions"
          hint="show --projects"
          onClick={() => onOpen("projects")}
        />

        {/* ✅ CERTIFICATIONS (REPLACED AWARDS) */}
        <Card
          icon="📜"
          title="Certifications"
          desc="Courses and professional credentials"
          hint="list --certifications"
          onClick={() => onOpen("certifications")}
        />

        <Card
          icon="📚"
          title="Skills"
          desc="Technologies and tools I use"
          hint="list --skills"
          onClick={() => onOpen("skills")}
        />

        <Card
          icon="✉️"
          title="Contact"
          desc="Let’s connect and collaborate"
          hint="open --contact"
          onClick={() => onOpen("contact")}
        />

      </div>
    </section>
  );
}

function Card({ icon, title, desc, hint, onClick }) {
  return (
    <motion.div
      style={card}
      whileHover={{ y: -6, boxShadow: "0 20px 60px rgba(77,181,255,0.25)" }}
      onClick={onClick}
    >
      <div style={iconStyle}>{icon}</div>
      <h3>{title}</h3>
      <p style={{ opacity: 0.65 }}>{desc}</p>
      <p style={hintStyle}>{hint}</p>
    </motion.div>
  );
}

/* ================= STYLES ================= */

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
  gap: "32px",
};

const card = {
  background: "var(--panel)",
  padding: "28px",
  borderRadius: "var(--radius-md)",
  cursor: "pointer",
};

const iconStyle = {
  fontSize: "1.6rem",
  marginBottom: "12px",
};

const hintStyle = {
  marginTop: "12px",
  fontSize: "0.85rem",
  opacity: 0.4,
};

