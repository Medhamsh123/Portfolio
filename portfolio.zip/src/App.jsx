import { useState, useEffect } from "react";
import Preloader from "./components/Preloader";
import Hero from "./components/Hero";
import Launchpad from "./components/Launchpad";
import ContentModal from "./components/ContentModal";

import Terminal from "./components/Terminal";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Contact from "./components/Contact";

export default function App() {
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(
    () => sessionStorage.getItem("lastModal") || null
  );

  /* =========================
     🔥 KEYBOARD SHORTCUTS
  ========================= */
  useEffect(() => {
    const handler = (e) => {
      const tag = document.activeElement?.tagName;

      // ❌ Don't trigger shortcuts while typing
      if (tag === "INPUT" || tag === "TEXTAREA") return;

      // ⌘K / Ctrl+K → Open terminal
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen("terminal");
      }

      // ESC → Close any modal
      if (e.key === "Escape") {
        setOpen(null);
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  /* =========================
     🧠 REMEMBER LAST MODAL
  ========================= */
  useEffect(() => {
    if (open) {
      sessionStorage.setItem("lastModal", open);
      document.body.classList.add("modal-open");
    } else {
      sessionStorage.removeItem("lastModal");
      document.body.classList.remove("modal-open");
    }
  }, [open]);

  /* =========================
     ⏳ PRELOADER
  ========================= */
  if (!ready) {
    return <Preloader onFinish={() => setReady(true)} />;
  }

  return (
    <>
      <Hero />
      <Launchpad onOpen={setOpen} />

      <ContentModal open={!!open} onClose={() => setOpen(null)}>
        {open === "terminal" && (
          <Terminal onClose={() => setOpen(null)} />
        )}

        {open === "about" && (
          <About onClose={() => setOpen(null)} />
        )}

        {open === "skills" && <Skills />}

        {open === "projects" && <Projects />}

        {open === "contact" && <Contact onClose={() => setOpen(null)} />}
      </ContentModal>
    </>
  );
}
