import { motion } from "framer-motion";

export default function About({ onClose }) {
  return (
    <div style={wrapper}>
      {/* TOP BAR (FIXED) */}
      <div style={topBar}>
        <button onClick={onClose} style={backBtn}>
          ← Back to home
        </button>
      </div>

      {/* CONTENT */}
      <div style={content}>
        {/* INTRO */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          style={intro}
        >
          <img
            src="/avatar.png"
            alt="Medhamsh avatar"
            style={avatar}
          />

          <div>
            <h1 style={title}>About Medhamsh</h1>
            <p style={subtitle}>
              Full Stack Developer · AI Enthusiast · Problem Solver
            </p>
          </div>
        </motion.div>

        {/* MY JOURNEY */}
        <section style={section}>
          <h2 style={sectionTitle}>My Journey</h2>

          <div style={journeyCard}>
            <p style={journeyText}>
              I’m a passionate developer who thrives at the intersection of
              <strong> technology, creativity, and real-world impact</strong>.
              My journey began with curiosity — breaking things, rebuilding them,
              and understanding how systems truly work.
            </p>

            <p style={journeyText}>
              Over time, I moved beyond just writing code to
              <strong> designing scalable, user-focused solutions</strong>.
              From modern web applications to intelligent systems, I focus on
              building software that feels intuitive, performant, and purposeful.
            </p>

            <p style={journeyText}>
              Today, my work reflects a balance of
              <strong> engineering depth and thoughtful design</strong>.
              I enjoy solving complex problems, learning emerging technologies,
              and continuously refining my craft.
            </p>

            <div style={journeyDivider} />

            <p style={journeyHighlight}>
              I don’t just build software — I build experiences that grow,
              adapt, and create value.
            </p>
          </div>
        </section>

        {/* DEVELOPMENT PHILOSOPHY */}
        <section style={section}>
          <h2 style={sectionTitle}>Development Philosophy</h2>

          <div style={philosophyBox}>
            <PhilosophyItem
              title="Solve Real Problems"
              desc="I dive deep into user challenges, building solutions that address genuine pain points rather than adding features for the sake of features."
            />
            <PhilosophyItem
              title="Build for Scale"
              desc="I architect systems that evolve with growth, anticipating future needs while delivering immediate value today."
            />
            <PhilosophyItem
              title="Ship Fast, Learn Faster"
              desc="I embrace rapid iteration, gathering feedback early and often to refine solutions based on real-world usage patterns."
            />
            <PhilosophyItem
              title="Share Knowledge"
              desc="I actively contribute to the developer community through collaboration and learning, because great ideas flourish when shared."
            />
            <PhilosophyItem
              title="Engineer for Tomorrow"
              desc="I write clean, maintainable code that future developers (including myself) will thank me for."
            />

            <div style={philosophyClosing}>
              <p>Technology should feel invisible when it works perfectly.</p>
              <strong>That’s the standard I code toward.</strong>
            </div>
          </div>
        </section>

        {/* WHAT I DO */}
        <section style={{ ...section, marginBottom: "24px" }}>
          <h2 style={sectionTitle}>What I Do</h2>
          <div style={grid}>
            <SkillCard title="Frontend">
              React · Animations · Clean UI · UX
            </SkillCard>
            <SkillCard title="Backend">
              APIs · Databases · Scalable Architecture
            </SkillCard>
            <SkillCard title="Logic & Systems">
              Automation · Intelligent Systems · Optimization
            </SkillCard>
          </div>
        </section>
      </div>
    </div>
  );
}

/* ================= COMPONENTS ================= */

function PhilosophyItem({ title, desc }) {
  return (
    <div>
      <h4 style={philosophyTitle}>{title}</h4>
      <p style={philosophyText}>{desc}</p>
    </div>
  );
}

function SkillCard({ title, children }) {
  return (
    <div style={card}>
      <h3>{title}</h3>
      <p style={{ opacity: 0.8 }}>{children}</p>
    </div>
  );
}

/* ================= STYLES ================= */

const wrapper = {
  maxHeight: "90vh",
  overflowY: "auto",
  padding: "24px",
};

const topBar = {
  position: "fixed",
  top: 0,
  left: 0,
  right: 0,
  padding: "12px 24px",
  background: "rgba(15,15,15,0.9)",
  backdropFilter: "blur(10px)",
  zIndex: 100,
};

const backBtn = {
  background: "none",
  border: "none",
  color: "var(--accent)",
  cursor: "pointer",
  fontSize: "0.85rem",
};

const content = {
  maxWidth: "900px",
  margin: "0 auto",
  paddingTop: "56px",
};

const intro = {
  display: "flex",
  gap: "20px",
  marginBottom: "28px",
};

const avatar = {
  width: "96px",
  height: "96px",
  borderRadius: "50%",
  border: "2px solid rgba(255,255,255,0.15)",
  boxShadow: "0 0 22px rgba(77,181,255,0.35)",
  objectFit: "cover",
};

const title = { fontSize: "2rem" };
const subtitle = { opacity: 0.7 };

const section = { marginBottom: "36px" };
const sectionTitle = { fontSize: "1.5rem", marginBottom: "14px" };

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
  gap: "16px",
};

const card = {
  padding: "18px",
  borderRadius: "14px",
  background:
    "linear-gradient(180deg, rgba(77,181,255,0.08), rgba(255,255,255,0.02))",
  border: "1px solid rgba(77,181,255,0.25)",
};

/* ===== JOURNEY STYLES ===== */

const journeyCard = {
  padding: "22px",
  borderRadius: "16px",
  background:
    "linear-gradient(180deg, rgba(77,181,255,0.12), rgba(155,92,255,0.05))",
  border: "1px solid rgba(77,181,255,0.35)",
};

const journeyText = {
  opacity: 0.85,
  lineHeight: 1.6,
  marginBottom: "12px",
};

const journeyDivider = {
  height: "1px",
  background:
    "linear-gradient(90deg, transparent, var(--accent), transparent)",
  margin: "16px 0",
};

const journeyHighlight = {
  textAlign: "center",
  color: "var(--accent)",
  fontSize: "0.95rem",
  fontWeight: 500,
};

/* ===== PHILOSOPHY ===== */

const philosophyBox = {
  padding: "22px",
  borderRadius: "16px",
  background:
    "linear-gradient(180deg, rgba(255,165,0,0.06), rgba(255,255,255,0.02))",
  border: "1px solid rgba(255,165,0,0.35)",
  display: "flex",
  flexDirection: "column",
  gap: "14px",
};

const philosophyTitle = {
  color: "var(--accent)",
  marginBottom: "4px",
};

const philosophyText = {
  opacity: 0.8,
  lineHeight: 1.55,
};

const philosophyClosing = {
  marginTop: "10px",
  paddingTop: "10px",
  borderTop: "1px solid rgba(255,255,255,0.15)",
  opacity: 0.85,
};
