import { motion } from "framer-motion";

export default function Contact({ onClose }) {
  return (
    <div style={page}>
      {/* Top bar */}
      <div style={topBar}>
        <span style={back} onClick={onClose}>← Back to home</span>
        <a
          href="/Medhamsh_Resume.pdf"
          style={resumeLink}
          download
        >
          Download Resume ⬇
        </a>
      </div>

      {/* Header */}
      <div style={header}>
        <h1 style={title}>
          Let’s <span style={{ color: "#4db5ff" }}>Connect</span>
        </h1>
        <p style={subtitle}>
          Whether you have a project in mind or just want to chat about tech,
          I’m always excited to connect with fellow developers and collaborators.
        </p>
      </div>

      {/* Layout */}
      <div style={layout}>
        {/* LEFT */}
        <div style={left}>
          <Card
            title="Email Me"
            text="yarlagaddamedhamsh@gmail.com"
            link="mailto:yarlagaddamedhamsh@gmail.com"
          />

          <Card
            title="LinkedIn"
            text="Connect Professionally"
            link="https://www.linkedin.com/in/medhamsh-yarlagadda-05854b326/"
          />

          <Card
            title="GitHub"
            text="Check My Code"
            link="https://github.com/Medhamsh123"
          />

          <Card
            title="Portfolio"
            text="View My Work"
            accent
            link="#"
          />

          <div style={card}>
            <h3 style={cardTitle}>Current Status</h3>
            <p>📍 India</p>
            <p>✅ Open to opportunities</p>
          </div>

          {/* RESUME CARD */}
          <div style={card}>
            <h3 style={cardTitle}>Resume</h3>
            <a
              href="/Medhamsh_Resume.pdf"
              download
              style={btn}
            >
              ⬇ Download CV
            </a>
          </div>
        </div>

        {/* RIGHT */}
        <motion.form
          style={form}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <label style={label}>Your Name *</label>
          <input placeholder="John Doe" style={input} />

          <label style={label}>Email Address *</label>
          <input placeholder="john@example.com" style={input} />

          <label style={label}>Message *</label>
          <textarea
            placeholder="Tell me about your project or inquiry..."
            style={{ ...input, minHeight: 120 }}
          />

          <button type="button" style={send}>
            ✈ Send Message
          </button>
        </motion.form>
      </div>
    </div>
  );
}

/* ============ CARD COMPONENT ============ */

function Card({ title, text, link, accent }) {
  const content = (
    <>
      <h3 style={cardTitle}>{title}</h3>
      <p style={{ opacity: 0.75 }}>{text}</p>
    </>
  );

  return link ? (
    <a
      href={link}
      target="_blank"
      rel="noreferrer"
      style={{
        ...card,
        textDecoration: "none",
        color: "white",
        borderColor: accent
          ? "rgba(77,181,255,0.6)"
          : "rgba(255,255,255,0.12)",
        boxShadow: accent
          ? "0 0 25px rgba(77,181,255,0.15)"
          : "none",
      }}
    >
      {content}
    </a>
  ) : (
    <div style={card}>{content}</div>
  );
}

/* ============ STYLES ============ */

const page = {
  padding: "40px",
  color: "white",
};

const topBar = {
  display: "flex",
  justifyContent: "space-between",
  marginBottom: "40px",
};

const back = {
  cursor: "pointer",
  color: "#4db5ff",
};

const resumeLink = {
  color: "#4db5ff",
  textDecoration: "none",
};

const header = {
  textAlign: "center",
  marginBottom: "60px",
};

const title = {
  fontSize: "2.6rem",
  fontWeight: 700,
};

const subtitle = {
  maxWidth: "600px",
  margin: "16px auto 0",
  opacity: 0.7,
};

const layout = {
  display: "grid",
  gridTemplateColumns: "1fr 1.2fr",
  gap: "40px",
};

const left = {
  display: "grid",
  gap: "20px",
};

const card = {
  padding: "18px",
  borderRadius: "14px",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.12)",
};

const cardTitle = {
  marginBottom: "6px",
};

const form = {
  padding: "28px",
  borderRadius: "18px",
  background:
    "linear-gradient(180deg, rgba(77,181,255,0.12), rgba(0,0,0,0))",
  border: "1px solid rgba(77,181,255,0.35)",
};

const label = {
  fontSize: "0.85rem",
  opacity: 0.8,
};

const input = {
  width: "100%",
  margin: "8px 0 18px",
  padding: "12px",
  borderRadius: "10px",
  background: "rgba(0,0,0,0.4)",
  border: "1px solid rgba(255,255,255,0.15)",
  color: "white",
  outline: "none",
};

const send = {
  width: "100%",
  padding: "14px",
  borderRadius: "12px",
  border: "none",
  background: "linear-gradient(90deg, #4db5ff, #9b5cff)",
  color: "black",
  fontWeight: 600,
  cursor: "pointer",
};

const btn = {
  display: "inline-block",
  marginTop: "10px",
  padding: "10px 14px",
  borderRadius: "10px",
  background: "linear-gradient(90deg, #4db5ff, #9b5cff)",
  color: "black",
  textDecoration: "none",
  fontWeight: 600,
};
